01_Project_Summary

Last updated: 2026-09-01

Project goal: Backyard Homestead Blog, a blog about small-scale urban homesteading and gardening.

Current status: Monetized via affiliate links and one sponsor post per month. Recently decided to add a paid newsletter tier starting in October.
