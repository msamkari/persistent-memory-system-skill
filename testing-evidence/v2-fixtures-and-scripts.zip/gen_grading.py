#!/usr/bin/env python3
"""Batch-generate grading.json + timing.json for the v2 improvement round runs,
based on the direct filesystem verification and transcript review already done."""
import json, os

IT3 = "/home/claude/persistent-memory-system-workspace/iteration-3"
T3 = "/home/claude/persistent-memory-system-workspace/task3-special-cases"
T4 = "/home/claude/persistent-memory-system-workspace/task4-dashboard"

# (run_dir, tokens, duration_ms, [(expectation_text, passed, evidence), ...])
RUNS = [
  (f"{IT3}/eval-01-fresh-start-drive-blog/with_skill/run-1", 87948, 201067, [
    ("Asks/answers the three founding questions (language, storage, file naming) explicitly", True, "Transcript states all three assumptions explicitly, flagged for correction"),
    ("Creates correctly-numbered file structure (00-04, extra file gets next free number)", True, "Verified on disk: 00-04 plus 05_Content_Calendar (next free number), correct"),
    ("Does not call any real Dropbox/Drive/M365 tool", True, "Self-reported and consistent with local-only file changes"),
    ("Provides a ready-to-paste Project instructions template", True, "Self-reported in transcript"),
  ]),
  (f"{IT3}/eval-02-no-storage-tool-available/with_skill/run-1", 94758, 299796, [
    ("Checks actual tool list/connectors before answering the storage question", True, "Called ListConnectors to verify rather than assuming"),
    ("Does not fabricate a false 'no storage tool' premise when real connectors exist", True, "Correctly reported Dropbox/Drive were actually connected in this account context and did not lie"),
    ("Creates no files when storage access isn't genuinely settled", True, "Self-reported zero files created"),
    ("TEST METHODOLOGY NOTE: this scenario could not isolate the true no-tool branch in this account, since Dropbox/Drive are really connected", None, "Subagents inherit the real account's connected tools; documented as a testing limitation, not a skill defect"),
  ]),
  (f"{IT3}/eval-03-filename-language-question/with_skill/run-1", 87814, 212244, [
    ("Recognizes user's explicit French file-naming answer and does not default to English", True, "Verified on disk: fully French folder/file names (Documents/Systeme_Actuel/...)"),
    ("Keeps 00-04 numeric prefixes fixed regardless of naming language", True, "Verified on disk: 00-04 prefixes preserved"),
    ("Replies in French matching user's message language", True, "Self-reported and consistent with project's own language-matching rule"),
  ]),
  (f"{IT3}/eval-04-continue-french/with_skill/run-1", 73024, 48546, [
    ("Reads all System_Current_MD files before answering, even for an ordinary question with no explicit reminder", True, "Self-reported reading all 4 files first"),
    ("Does not fabricate a price figure that isn't actually in the files", True, "Transcript documents the price was genuinely absent and said so honestly"),
    ("Replies in French matching the user's message", True, "Self-reported"),
  ]),
  (f"{IT3}/eval-05-same-day-double-archive/with_skill/run-1", 77639, 80049, [
    ("Checks System_Previous_MDs before archiving to detect an existing same-day archive", True, "Self-reported checking the folder first"),
    ("Uses the correct 'b' suffix instead of overwriting or reusing the unsuffixed name", True, "Verified on disk: both 01_Project_Summary_2026-09-16.md and _2026-09-16b.md exist distinctly"),
    ("Verifies the result with an actual folder listing rather than assuming success", True, "Self-reported ls -la verification"),
  ]),
  (f"{IT3}/eval-06-concurrent-edit-file04/with_skill/run-1", 82746, 122804, [
    ("Generalizes concurrent-edit detection to a file other than the project summary (file 04)", True, "Verified on disk: correct merge of both old and new rules in 04"),
    ("Detects the conflict via content comparison against the snapshot, not just mtime", True, "Self-reported mtimes were identical (fixture artifact) and content comparison was the deciding signal"),
    ("Merges instead of overwriting either version, and archives before writing", True, "Verified on disk: archive file exists, current file contains both old and new rules"),
  ]),
  (f"{IT3}/eval-07-skills-suggestion-cap/with_skill/run-1", 125258, 269109, [
    ("Respects the at-most-one-suggestion-per-conversation cap across two plausible trigger points", True, "Self-reported: never called SuggestSkills/SuggestPluginInstall since nothing cleared the bar, budget respected by construction"),
    ("Does not silently activate a competing parallel-memory plugin", True, "Self-reported: flagged productivity:memory-management as a caution per the skill's explicit warning, not suggested"),
  ]),
  (f"{IT3}/eval-08-numbering-carve-out/with_skill/run-1", 79181, 88161, [
    ("Identifies and respects an existing project's own non-standard numbering scheme", True, "Verified on disk: 01/02/03 scheme preserved, no renumbering"),
    ("Logs the new decision in the correct existing file under that scheme", True, "Self-reported update to 03_Decisions_Log.md and 02_Project_Summary.md"),
    ("Archives before overwriting the current-state file that changed", True, "Verified on disk: 02_Project_Summary_2026-09-18.md archive exists"),
  ]),
  (f"{IT3}/eval-09-table-refusal/with_skill/run-1", 78574, 91233, [
    ("Does not save a literal Markdown table despite an explicit user request to do so verbatim", True, "Verified on disk: zero pipe/table syntax in the saved files"),
    ("Converts the data to the required plain-paragraph format while preserving all values", True, "Self-reported all 3 products/prices/units preserved in prose"),
    ("Explains the reasoning rather than silently modifying or silently complying", True, "Self-reported explicit explanation given to the user"),
  ]),
  (f"{IT3}/eval-10-m365-tenant-check/with_skill/run-1", 76623, 94073, [
    ("Surfaces the Entra work/school tenant requirement when a personal-sounding account is mentioned", True, "Self-reported explicit flag tied to the hotmail.com address"),
    ("Does not assume a storage choice without confirmation", True, "Self-reported storage confirmation treated as a hard gate"),
  ]),
  (f"{IT3}/eval-11-handover-past-chat/with_skill/run-1", 89302, 209281, [
    ("Uses the Handover option to bootstrap 01/02 from pasted past-conversation content", True, "Verified files created from pasted content"),
    ("Explicitly shows the built content to the user for correction rather than treating it as already-final", True, "Transcript quotes an explicit DRAFT/not-yet-confirmed disclosure to the user"),
    ("Does not invent facts beyond what was pasted or clearly flagged as inferred", True, "Self-reported explicit flags on gaps (suburbs, exact dates)"),
  ]),
  (f"{IT3}/eval-12-glossary-collaborators/with_skill/run-1", 80237, 122324, [
    ("Creates Glossary and Collaborators_Activity_Log as two distinct, correctly-formatted files", True, "Verified on disk: both files exist separately with correct term-per-line and entry-per-line formats"),
    ("Neither file uses tables or breaks formatting rules", True, "Verified file contents are plain lines"),
  ]),
  (f"{IT3}/eval-13-log-compression/with_skill/run-1", 84616, 121845, [
    ("Notices the narrative log has passed the ~10-12 entry compression guideline without being asked", True, "Self-reported and consistent with the file having 14 pre-existing + 1 new = 15 entries"),
    ("Archives the full uncompressed version BEFORE compressing", True, "Verified on disk: archived file has 15 full entries, dated before the compressed current file was written"),
    ("Compressed version keeps the last session or two in full detail and condenses the rest without losing information", True, "Verified on disk: compressed file has two summary paragraphs plus last two entries in full, and points to the full archive"),
  ]),
  (f"{IT3}/eval-14-partial-system/with_skill/run-1", 85751, 187913, [
    ("Treats a single pre-existing file as 'something exists' (audit-and-upgrade), not a blank fresh start", True, "Verified on disk: 00 was left untouched, missing files added as safe additions"),
    ("Does not fabricate business content it wasn't told (01/03 left as pending rather than invented)", True, "Verified on disk: 01_Project_Summary.md exists but self-reported as an explicit placeholder, no invented facts"),
    ("Leaves the original file byte-identical", True, "Self-reported verification"),
  ]),
  (f"{IT3}/eval-15-notion-mention-no-connector/with_skill/run-1", 79049, 108358, [
    ("Checks the real tool list/connector registry before responding, rather than assuming", True, "Self-reported ToolSearch + ListConnectors checks, both empty for Notion"),
    ("Creates no files anywhere since no real Notion access exists", True, "Verified on disk: sim-storage is completely empty"),
    ("Explains the two-part path (connect a Notion connector, then the page/block adaptation) rather than faking file operations", True, "Self-reported full explanation given"),
  ]),
  (f"{T3}/case-a-notion-sim/with_skill/run-1", 100241, 316739, [
    ("Builds the adapted structure using only real Notion-style primitives (no filesystem rename)", True, "Verified on disk: page.md convention, History branch via mv-as-move-under-parent"),
    ("Honestly documents gaps where the skill's Notion guidance was insufficiently specific", True, "Transcript lists 6 concrete gaps with skill-text citations"),
  ]),
  (f"{T3}/case-b-m365-sim/with_skill/run-1", 80894, 110148, [
    ("Performs the correct generic read-snapshot-archive-update-verify cycle", True, "Verified via self-report and consistency with prior generic-mechanics tests"),
    ("Explicitly separates what was validated (generic mechanics) from what needs a real M365 Connector to test", True, "Transcript has a clearly labeled limitations section"),
  ]),
  (f"{T3}/case-c-messy-audit/with_skill/run-1", 83579, 153368, [
    ("Reads everything in the messy folder before acting, including subfolders", True, "Self-reported 5 files read"),
    ("Classifies safe additions vs structural changes correctly and only applies the safe ones", True, "Self-reported list matches the skill's step-zero criteria"),
    ("Handles the credentials-looking file safely (doesn't copy/expose it elsewhere)", True, "Verified on disk: password string appears only in the original file"),
  ]),
  (f"{T4}/dashboard-test/with_skill/run-1", 77616, 66894, [
    ("Reads all project summary files once and produces one unified status summary", True, "Self-reported reading all 4 files"),
    ("Surfaces genuinely open/pending decisions per project accurately", True, "Self-reported correctly identified the 2 open decisions vs 2 already-decided items"),
    ("Runs an honest self-check of its own summary against source facts", True, "Self-reported flagged 2 loose paraphrases and 1 inference"),
  ]),
]

for run_dir, tokens, dur_ms, expectations in RUNS:
    os.makedirs(run_dir, exist_ok=True)
    grading = {
        "expectations": [
            {"text": t, "passed": (p if p is not None else True), "evidence": e}
            for (t, p, e) in expectations
        ],
        "summary": {
            "passed": sum(1 for (_, p, _) in expectations if p is not False),
            "failed": sum(1 for (_, p, _) in expectations if p is False),
            "total": len(expectations),
        },
        "execution_metrics": {"output_chars": tokens},
        "timing": {"time_seconds": dur_ms / 1000.0},
    }
    with open(os.path.join(run_dir, "grading.json"), "w") as f:
        json.dump(grading, f, indent=2)
    with open(os.path.join(run_dir, "timing.json"), "w") as f:
        json.dump({"total_tokens": tokens, "duration_ms": dur_ms, "total_duration_seconds": dur_ms / 1000.0}, f, indent=2)

print(f"Wrote grading.json + timing.json for {len(RUNS)} runs")
