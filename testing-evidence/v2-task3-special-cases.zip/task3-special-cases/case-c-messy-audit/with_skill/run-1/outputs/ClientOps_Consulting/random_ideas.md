# ideas
- maybe raise rates for new clients in Q3
- ask Byline Media for a testimonial
