00_Archiving_Rule

No direct deletion of system files ever. Archive superseded versions to System_Previous_MDs/[YYYY-MM]/ with today's date, create a fresh current file, verify with a folder listing.
