# Transcript — Case B: Microsoft 365/SharePoint Simulation (with_skill, run-1)

Test date: 2026-09-18
Skill under test: persistent-memory-system (SKILL.md read in full before this run)
Storage used: a local filesystem directory standing in for a SharePoint document
library. No real Microsoft 365, SharePoint, OneDrive, Dropbox, Google Drive, or
Notion MCP tool was called at any point in this test.

Simulated path:
sim-storage/SharePoint_Site_ProjectDocs/MDs/System_Current_MD/

User message tested:
"We're using our company SharePoint for this. Quick update - 20 of the 40
employees are now migrated, up from 15."

---

## Step 1 — Mandatory read of System_Current_MD (before any real reply)

Per the skill's "first mandatory step in any following session" rule, the
current-state folder was read in full before treating the user's update as
actionable:

- 00_Archiving_Rule.md — the standing no-direct-deletion / archive-then-replace
  rule.
- 01_Project_Summary.md — last updated 2026-08-10, stating: "Internal IT
  migration project, moving 40 employees from on-prem file shares to
  SharePoint. Current status: 15 of 40 employees migrated so far."

No 02_Decisions_and_Lessons_Log.md existed yet in this project. Per the
skill's audit-and-upgrade path, a missing standing category is a "safe
addition" (does not rename/restructure anything already working) and can be
created without waiting for explicit sign-off, so it was flagged for creation
in this same session rather than skipped or deferred.

## Step 2 — Freshness snapshot (pre-write)

A snapshot of System_Current_MD was taken before any write:
- 00_Archiving_Rule.md, 01_Project_Summary.md — both present, both timestamped
  identically from setup, sizes 200 and 204 bytes.
- System_Previous_MDs/ existed but was empty (no prior archives yet).

Immediately before writing, 01_Project_Summary.md was hashed again and
compared to the snapshot: unchanged. No concurrent-edit conflict — safe to
proceed.

## Step 3 — Archive (no direct deletion)

1. Created System_Previous_MDs/2026-09/ (did not exist yet).
2. Copied the current 01_Project_Summary.md into that folder as
   01_Project_Summary_2026-09-18.md (today's date appended, per the naming
   rule).
3. Verified the archived copy's content matches the pre-update file exactly
   (15/40, last updated 2026-08-10) — confirmed byte-for-byte via direct
   read-back, not assumed.

## Step 4 — Update current-state file

01_Project_Summary.md in System_Current_MD was replaced in full with:

    01_Project_Summary
    Last updated: 2026-09-18
    Project goal: Internal IT migration project, moving 40 employees from
    on-prem file shares to SharePoint.
    Current status: 20 of 40 employees migrated so far (up from 15 as of
    2026-08-10).

## Step 5 — Log the development (narrative-historical file)

Per the skill's "automatic update for any material decision or development"
rule, this status change is exactly the kind of update that must be recorded
in the same session without being asked twice. Since no 02 log file existed,
it was created now (02_Decisions_and_Lessons_Log.md) with an opening note
explaining why it's being created now (missing category, safe addition, not a
restructure) plus a dated entry for this update: 15 -> 20 of 40, reported
directly by the user, cross-referenced to the 01 update and its archive.

## Step 6 — Verification (re-listed, not assumed)

Re-listed both folders directly after writing:
- System_Current_MD now contains: 00_Archiving_Rule.md (unchanged),
  01_Project_Summary.md (new content, 234 bytes), 02_Decisions_and_Lessons_Log.md
  (new file, 674 bytes).
- System_Previous_MDs/2026-09/ now contains 01_Project_Summary_2026-09-18.md
  (204 bytes) with the original 15/40, 2026-08-10 content intact.

No file was deleted at any point. The prior version is fully recoverable from
the archive.

---

## Self-Reported Metrics

- Files read before acting: 2 of 2 existing current-state files (00, 01) —
  full read, 100% of the mandatory pre-reply step.
- Files updated: 1 (01_Project_Summary.md).
- Files newly created: 1 (02_Decisions_and_Lessons_Log.md), flagged and
  justified as a safe addition rather than applied silently.
- Files archived: 1 (01_Project_Summary, dated copy), 0 files deleted.
- Freshness/conflict checks performed: 2 (snapshot at session start, hash
  re-check immediately before write). Conflicts found: 0.
- Verification passes after write: 1 full re-listing of both
  System_Current_MD and System_Previous_MDs, plus a direct content diff of
  the archived copy against the pre-update file.
- Real cloud/storage MCP tool calls made: 0 (Dropbox, Google Drive,
  Microsoft 365, Notion, or any other file-service connector). All file
  operations in this transcript were plain local filesystem operations
  against the path given for this test.
- Microsoft-365-specific behaviors exercised: 0 (see reflection below).

---

## Reflection: what this test actually validates vs. does not

### What genuinely CAN be verified this way (generic file/folder mechanics)

The skill explicitly states that real file-and-folder services (Dropbox,
Google Drive, Microsoft 365/OneDrive/SharePoint) all run the same archiving
mechanism unmodified — a plain folder-and-file model (move-and-rename instead
of delete, a dated subfolder per month, a fresh current file). Because that
mechanism has no Microsoft-specific logic in it, everything exercised in
Steps 1-6 above is a fair test of it, regardless of which real backend it
would eventually run against:

- The mandatory full read of System_Current_MD before treating a new message
  as actionable.
- Detecting that a standing category (02) was missing and treating its
  creation as a safe addition rather than either skipping it or silently
  restructuring something else.
- Taking a pre-write freshness snapshot and re-checking a specific file's
  state immediately before overwriting it, to catch a concurrent edit.
- The archive-before-overwrite sequence itself: copy current file to
  System_Previous_MDs/[YYYY-MM]/ with a dated filename, write a fresh
  current file, then verify by re-listing rather than assuming success.
- Logging a substantive update (15 -> 20 of 40) into the narrative-historical
  file in the same turn, unprompted.

All of that is genuinely exercised here, on a real (local) filesystem, with
real reads, writes, and verification — not simulated in the sense of being
faked or assumed.

### What this test could NOT verify (real M365 Connector limitation)

This is the part that must not be overclaimed. A local directory is not
SharePoint, and nothing below was touched by this run:

- Tenant / account-type gating. The skill itself notes that Microsoft 365
  requires a work/school account linked to an Entra tenant, and that personal
  outlook.com/hotmail.com accounts are typically not supported by the
  official connector. This test used no Microsoft account at all, so it
  cannot say anything about whether that gating behaves as described, what
  error a personal account actually produces, or whether "typically not
  supported" has exceptions in practice.
- The real Microsoft 365 Connector's authentication and consent flow (OAuth
  against Entra ID, admin consent requirements, conditional access policies)
  — none of this exists in a local directory.
- Actual SharePoint document library behavior: versioning history that
  SharePoint itself maintains, list-view metadata columns, content types,
  co-authoring locks, check-out/check-in semantics, or how SharePoint's own
  recycle bin interacts with a connector-driven "move to archive" operation.
- Microsoft Graph API quirks and limits specific to SharePoint/OneDrive:
  throttling behavior, item-count limits per folder, path-length limits,
  special characters disallowed in SharePoint file/folder names, sync-client
  (OneDrive) conflict resolution, or eventual-consistency delays between a
  write and that write becoming visible elsewhere.
- Permission scopes. Whether the connector's OAuth scopes actually allow
  read+write to a specific document library versus requiring broader
  Sites.ReadWrite.All-style access, and what the skill's advice to "turn off
  tools you don't need, keep only file read/write" looks like in Microsoft's
  actual scope picker.
- Whether SharePoint site structure (sites vs. document libraries vs.
  folders) maps cleanly onto the skill's assumed Dropbox/Drive-style flat
  folder tree, or whether a real integration would need adaptation the skill
  does not currently describe.
- Any error path unique to Microsoft 365 (expired token, tenant admin
  revoking consent mid-session, site-level permission denial) and whether the
  skill's "say so explicitly before continuing" rule actually fires
  correctly against those specific error shapes.

### Bottom line

This run is a valid, honest test of the skill's storage-agnostic archiving
logic, executed faithfully against a stand-in file tree. It is not evidence,
one way or the other, about how the skill behaves against a real Microsoft
365 Connector, and in particular says nothing about the personal-account
gating behavior the skill itself calls out. That would require an actual
Entra-tenant-linked Microsoft 365 Connector to test.
