# QA transcript — persistent-memory-system skill, Notion-primitive simulation

Case: task3-special-cases / case-a-notion-sim / with_skill / run-1

Important disclaimer up front: this is a **local filesystem simulation** of
Notion's primitives, as instructed. No real Notion MCP tool, and no real
Dropbox/Google Drive/Microsoft 365 tool, was called at any point in this run.
"Pages" are folders containing one `page.md` file; a "child page" is a
subfolder of its parent page's folder. Only three primitives were used,
exactly as specified in the task: (1) create a new page = `mkdir` + write
`page.md`, (2) edit an existing page = overwrite its `page.md` in place, (3)
"archive" a page = `mv` its folder under another page's folder, unchanged,
representing Notion's real "move page under another page" API action. No
rename primitive was used or assumed anywhere.

Skill file read in full before doing anything: `/home/claude/persistent-memory-system/SKILL.md`.

## 1. What was already there

`Freelance_Design_Workspace/page.md` — parent workspace page, boilerplate only.

`Freelance_Design_Workspace/Project_Notes/page.md` — one child page, scattered
scratch content: "Client: Aria Studio. Logo redesign, deadline mid-October.
Rate: 1200 USD flat."

## 2. Step-zero classification (skill's "خطوة صفر")

The skill's step zero asks whether an existing memory/organization system is
already in place — explicitly including an informal one, "a single narrative
file gathering decisions and notes." `Project_Notes` is borderline: it is
scattered, unorganized, single-topic scratch content, not a maintained
decision log or anything resembling the skill's own structure (no archiving
rule, no current/history split, no numbering). I classified this as **not**
an existing system — it's raw material for a brand-new build, not a prior
system to audit-and-upgrade — and took the skill's normal path (المسار
الطبيعي) rather than the audit-and-upgrade path. This judgment call is listed
under Gaps below, because the skill's own threshold ("even if informal") does
not give a crisp line between "informal existing system" and "just some
notes that happen to exist."

`Project_Notes` itself was left completely untouched (not renamed, not
archived, not deleted) — its content was only read and used as seed
material for the new system's summary and log pages, consistent with the
skill's optional "Handover" idea (build an initial summary/log from prior
material, but keep the source available).

## 3. Founding questions

The skill's three founding questions (language, storage location, file
naming) were not literally re-asked back to the user in this run, since the
task setup already fixes storage (this Notion-like workspace) and the user's
message doesn't answer language/naming. I applied the skill's own stated
defaults rather than inventing new ones:

- Language of content: skill's stated default when the user hasn't picked
  one explicitly — match the language of the user's current message. The
  user wrote in English, so all page content is in English.
- Page/folder naming: skill's stated default — English, since the user did
  not state a preference (this is recorded in `04_Language_and_Formatting_Rules`
  so a future session doesn't have to re-derive it).

In a real run I would still ask these explicitly rather than silently
defaulting, per the skill's own instruction not to assume an answer — this
run defaults them only because the test harness gives no live user to ask.

## 4. Final page tree built

```
Freelance_Design_Workspace/                          (existing, untouched)
  page.md
  Project_Notes/                                      (existing, untouched)
    page.md
  MDs/                                                 (new)
    page.md
    System_Current_MD/                                 (new)
      page.md
      00_Archiving_Rule/page.md
      01_Project_Summary/page.md
      02_Decisions_and_Lessons_Log/page.md
      03_Clients_and_Projects_Log/page.md
      04_Language_and_Formatting_Rules/page.md
    History/                                            (new)
      page.md
      2026-09/
        2026-09-18/
          01_Project_Summary/page.md   <- archived v1, moved here intact
```

## 5. Notion-specific adaptation decisions, mapped to exact skill guidance

**Decision A — an archive page replaces a renamed file.**
Skill text (verbatim, from the "خدمات قائمة على صفحات/بلوكات" paragraph):
"صفحة أرشيف بدل ملف مُعاد تسميته." Applied as: when `01_Project_Summary`
needed updating, I did not rename anything (no rename primitive exists). I
used primitive (3) — moved the *entire existing page*, unchanged, into
History — and primitive (1) — created a brand-new page with the same
original name back under `System_Current_MD` holding the new content. This
was actually executed in this run (not just described): see the `mv` command
and the before/after `ls` output. The moved page still holds its original,
pre-update content in `History/2026-09/2026-09-18/01_Project_Summary/page.md`.

**Decision B — a "History" parent page replaces a dated subfolder.**
Skill text: "صفحة أب 'History' بدل مجلد فرعي بتاريخ." Applied as: created a
top-level `History` page under `MDs`, sibling to `System_Current_MD`
(mirroring the original `System_Previous_MDs` sibling relationship to
`System_Current_MD`). Nested `2026-09` (month) and `2026-09-18` (day) pages
underneath it, echoing the original rule's `System_Previous_MDs/[YYYY-MM]/`
dated-subfolder convention, just realized as nested pages instead of nested
folders.

**Decision C — "same principles, different technical implementation."**
Skill text: "المبدأ يبقى نفسه (لا حذف، فصل current-state، قراءة إلزامية)،
التنفيذ التقني يتغيّر حسب بنية الخدمة." I used this line to justify
substituting the *mechanism* of archiving (move-then-recreate via primitives
1+3) for the original file-system mechanism (move-and-rename-then-recreate),
while keeping the three stated invariants intact: nothing was deleted, the
current-state page and its history stay physically separate, and the
mandatory-full-read instruction was written into `System_Current_MD/page.md`
unchanged in spirit.

**Decision D — narrative-historical pages stay append-only, no archiving
mechanism applied to them.**
Skill text (file categories section): 02 and 03 are "append-only" and only
"تُضاف له بلا حدود" until a length threshold triggers compression — nothing
in the skill ties narrative pages to the archive-page/History mechanism at
all, on real filesystems or on Notion. Applied literally: `02_Decisions_and_Lessons_Log`
and `03_Clients_and_Projects_Log` were both edited in place (Edit tool, not
mv/mkdir) to append the new entries, with no History involvement, matching
how a real Dropbox-based run would just append to the same .md file.

**Decision E — automatic update of a new decision, same session, no
prompting.**
Skill text: "أي قرار جديد أو تطور مهم يظهر أثناء أي جلسة يُسجَّل فوراً...
بدون انتظار طلب صريح." Applied as: the Aria Studio deadline correction and
the new Bloom Bakery client were logged into 02 and 03, and folded into 01,
within the same run, without waiting to be asked to "save" or "log" them.

**Decision F — freshness check before overwrite.**
Skill text describes a one-snapshot-per-session freshness check before
overwriting any current-state file. Applied conceptually and stated in the
adapted `00_Archiving_Rule` page (Notion equivalent: check the page's
last-edited state before overwriting) — not literally exercised against a
second concurrent session in this run, since there was only one writer.

## 6. Gaps in the skill's Notion guidance

These are the places where the single paragraph on page/block-based
services was not concrete enough to act on without a judgment call or an
outright guess:

1. **No mechanism given for the "date-stamped filename" requirement when
   there is no rename primitive.** The original archiving rule requires the
   archived object to end up named `original_name_YYYY-MM-DD` (with a `b`/`c`
   suffix for same-day repeats). Notion pages can't be renamed by an
   integration per the task's own constraints, and the skill's Notion
   paragraph doesn't address this at all — it only says "History page
   instead of dated subfolder," not how to preserve the date-on-the-object
   information once you can no longer put the date in the object's own name.
   I resolved this by inventing a day-level intermediate page
   (`History/2026-09/2026-09-18/`) so the date lives in newly-created
   container pages instead of on the archived page's name, and reserved the
   `b`/`c` same-day suffix for that new day-page's name rather than the
   archived page's name. This is a reasonable design, but it is my own
   invention, not something derivable from the skill text.

2. **Move vs. copy is not disambiguated.** The task's own primitive (3)
   description implies a real page-move (preserving page identity, ID,
   comments), which is what I used. But an equally defensible reading of
   "صفحة أرشيف بدل ملف مُعاد تسميته" is *copy the old content into a new,
   already-dated archive page, then edit the current page's content in
   place* — which would let the "current" page's Notion page-ID/URL stay
   permanently stable across every update (arguably more idiomatic for how
   people actually bookmark/link Notion pages) at the cost of the archived
   copy being a new object rather than the literal original. The skill gives
   no way to choose between these two structurally different designs; I
   picked move-then-recreate mainly because the task's primitive (3) most
   directly supports it, not because the skill text pointed there.

3. **The "MDs" / "System_Current_MD" naming itself is not revisited for
   Notion.** Both names are filesystem/Markdown-specific ("MD" = Markdown
   file). The skill's Notion paragraph only touches the archive/History
   substitution, not whether page *titles* inherited wholesale from the
   file-based convention still make sense once "page" replaces "file." I
   kept the names literally, since the skill elsewhere is explicit that
   numbering/naming shouldn't be improvised — but a Notion-native workspace
   would arguably never have a page called "System_Current_MD." This is a
   guess, not a documented decision.

4. **No guidance on Notion's lack of enforced ordering.** The skill's
   `00`-`04` numbering assumes alphabetical-sort behavior that a real
   filesystem gives for free. Notion's child-page list under a parent is a
   manually-orderable list, not alphabetically sorted by title. The skill
   never flags that this assumption breaks on a page/block service. I had
   to notice this myself and write a note about it into
   `04_Language_and_Formatting_Rules` — nothing in the skill prompted it.

5. **No guidance on what to do with a pre-existing loose page whose content
   gets absorbed into the new system** (here, `Project_Notes`). Should it be
   archived under History too once migrated, left alone forever, or get a
   pointer note added to it? I chose "leave it completely untouched" as the
   safest option (avoids any risk of altering content that isn't part of
   the system being built), but the skill doesn't say anything about this
   scenario for either filesystem or Notion-style storage.

6. **Step-zero's "informal existing system" threshold is vague in
   general**, and this shows up more sharply on Notion, where almost any
   pre-existing page could be argued to be "a note-gathering structure."
   The `Project_Notes` classification in section 2 above required a
   judgment call the skill doesn't equip you to make consistently.

## 7. Self-Reported Metrics

- Skill instructions that were directly actionable without guessing: the
  file-category list and numbering (00-04), the append-only vs. current-state
  split, the "no deletion" principle, the mandatory-full-read instruction,
  the immediate-save-of-any-shown-output rule, the automatic-logging-of-new-decisions
  rule, the no-tables/no-heavy-Markdown formatting rules, and the top-level
  "use an archive page + History parent page, not a renamed file + dated
  subfolder" framing for Notion-like services.
- Skill instructions that required improvisation/guessing to actually
  execute on Notion primitives: 4 distinct points (see Gaps 1-4 above),
  the most significant being gap 1 (no answer for how to date-stamp an
  archived object with no rename primitive available) and gap 2 (move vs.
  copy semantics left undetermined).
- Number of real archive cycles actually executed in this run: 1
  (`01_Project_Summary`, 2026-09-18), verified by listing both
  `System_Current_MD` and the new `History` event page after the move,
  per the skill's "تحقق فعلياً" (actually verify, don't assume) instruction.
- Number of narrative-log append operations executed: 2 pages updated
  (`02_Decisions_and_Lessons_Log`, `03_Clients_and_Projects_Log`), 3 new
  entries added total.
- Real external tools called: 0 (Dropbox/Drive/M365/Notion MCP tools were
  never invoked, per the mandatory safety rule for this test — everything
  above is local `mkdir`/`mv`/file-write against the simulated workspace
  path only).
- Pre-existing content altered or deleted: 0 files (`Project_Notes/page.md`
  and the root `page.md` are byte-for-byte unchanged from before this run).
