[Notion Page: 02_Decisions_and_Lessons_Log]

Decisions and lessons log (append-only — new entries added at the end, oldest never deleted)

2026-09-18 — Set up the persistent memory system for this Notion workspace, adapted from the standard file-based version: an archive page under History takes the place of a renamed file, and a History parent page (organized by month, then by day) takes the place of a dated subfolder. Seeded the initial project summary from the pre-existing Project_Notes page rather than deleting or rewriting that page.

2026-09-18 — Aria Studio deadline corrected from mid-October to October 20, 2026. New client Bloom Bakery added (brand identity package, 2000 USD flat, deadline not yet set). 01_Project_Summary updated; the prior version was archived intact to History greater-than 2026-09 greater-than 2026-09-18 greater-than 01_Project_Summary, following the archiving rule in 00_Archiving_Rule.
