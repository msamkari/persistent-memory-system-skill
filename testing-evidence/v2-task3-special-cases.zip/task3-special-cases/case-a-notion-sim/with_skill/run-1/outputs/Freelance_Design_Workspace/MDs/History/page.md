[Notion Page: History]

Archive of prior versions of this project's current-state pages (00, 01, 04, and any later numbered rule page). Organized as History greater-than a YYYY-MM month page greater-than a YYYY-MM-DD event page (a letter suffix such as -b is added to the event page's name if more than one archiving event happens the same day) greater-than the archived page itself, moved here intact under its original name with its original content untouched. Nothing under this page is ever deleted.
