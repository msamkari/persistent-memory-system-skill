[Notion Page: MDs]

Container page for this project's persistent memory system. Two child pages live under this one: System_Current_MD (the live reference that must be read in full at the start of every session on this project) and History (archived prior versions of current-state pages — nothing here is ever deleted, only moved).
