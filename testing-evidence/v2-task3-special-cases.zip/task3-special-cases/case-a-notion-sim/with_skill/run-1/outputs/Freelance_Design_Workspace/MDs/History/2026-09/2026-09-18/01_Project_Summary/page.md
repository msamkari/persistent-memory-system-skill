[Notion Page: 01_Project_Summary]

Project summary, current as of 2026-09-18

Business: solo freelance design practice.

Active clients and projects:
Aria Studio — logo redesign. Deadline: mid-October 2026. Rate: 1200 USD flat.

No other active clients recorded yet. This page is replaced in full whenever a client, project, deadline, or rate changes. See 03_Clients_and_Projects_Log for the full narrative history behind each line here.
