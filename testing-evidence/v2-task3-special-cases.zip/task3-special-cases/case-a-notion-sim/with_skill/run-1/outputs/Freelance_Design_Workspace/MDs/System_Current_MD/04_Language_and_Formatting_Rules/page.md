[Notion Page: 04_Language_and_Formatting_Rules]

Content language: English, matching the language the user was actually using when this system was set up (2026-09-18). If a later session is conducted in a different language, match that session's language for that reply, without permanently switching the whole system's language unless the user says so explicitly.

Page and folder naming: English, consistently, since the user was not asked to choose otherwise and did not state a preference when this system was set up.

Formatting inside every system page: no tables, no heavy nested Markdown (no stacked heading levels, no repeated horizontal rules, no deeply nested lists) — plain paragraphs, a plain-text heading line, and a blank line between sections, so the page still reads cleanly even somewhere that does not render Markdown. Dates as YYYY-MM-DD.

Notion-specific note: page order under a parent in Notion is a manual, draggable order, not the automatic alphabetical sort a file browser gives a folder. The 00/01/02... numbering carried into each page title here is a readability convention only — it does not by itself force pages to display in that order. When a new numbered page is added, drag it into the matching position under its parent so the visible order matches the numbering.
