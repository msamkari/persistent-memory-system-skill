[Notion Page: 03_Clients_and_Projects_Log]

Clients and projects log (append-only, narrative — one running record per client)

Aria Studio
2026-09-18 — Logo redesign engagement recorded. Deadline mid-October 2026. Rate 1200 USD flat. Source: pre-existing Project_Notes page content, migrated in during system setup, original page left untouched.
2026-09-18 — Deadline corrected to October 20, 2026.

Bloom Bakery
2026-09-18 — New client. Brand identity package. Rate 2000 USD flat. Deadline not yet set.
