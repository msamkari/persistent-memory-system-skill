[Notion Page: System_Current_MD]

Read this page and every child page under it in full before responding to any request on this project, in any session, even if the request looks routine or unrelated to project details. Child pages: 00_Archiving_Rule, 01_Project_Summary, 02_Decisions_and_Lessons_Log, 03_Clients_and_Projects_Log, 04_Language_and_Formatting_Rules.
