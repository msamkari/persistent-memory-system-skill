[Notion Page: 00_Archiving_Rule]

Archiving rule, adapted for this Notion-like workspace (not a real file/folder service)

This project's persistent memory lives as Notion pages, not as files in folders. An integration here cannot rename or freely move a page except through Notion's real "move a page under another page" action, so the standard persistent-memory-system archiving rule (written for Dropbox/Drive/Microsoft 365, where a file gets renamed with a date and moved into a dated subfolder) has been adapted below. The underlying principle is unchanged from the standard rule: never delete a system page, always keep the live current-state page separate from its history, and read every current-state page in full at the start of every session.

Freshness check, once per session before any update: reread the current-state page you are about to update (or check its last-edited time) and compare it against what you last recorded. If it changed since then, stop, say so to the user explicitly, reread the live version in full, and merge the two versions rather than overwriting either one blind.

When a current-state page (00, 01, 04, or any later numbered rule page) needs to be updated, after the freshness check above:
1. If it does not exist yet, create the current month's page under History (named YYYY-MM), then under that create today's event page (named YYYY-MM-DD, with a letter suffix such as -b if this is not the first archiving event of the day).
2. Move the existing current-state page, unchanged, under that new dated event page. This is a real page move: the page keeps its original name and its exact prior content, only its parent page changes.
3. Create a brand-new page with the original name (for example 01_Project_Summary) back under System_Current_MD, containing the updated content.
4. Confirm the result by actually listing System_Current_MD and the new History event page — do not assume the move and the new page both succeeded without checking.

Narrative-historical pages (02_Decisions_and_Lessons_Log, 03_Clients_and_Projects_Log) are never archived through the steps above — they are append-only, so a new entry is simply added at the end of the page. If a narrative page grows past roughly 10-12 entries, or gets long enough to noticeably slow down the mandatory full read at the start of a session, compress the older entries that are not tied to an active decision into one or two summary lines per batch, keeping the most recent session or two in full detail. Before compressing, save the complete uncompressed page as a History page through the same four steps above, so no detail is lost.
