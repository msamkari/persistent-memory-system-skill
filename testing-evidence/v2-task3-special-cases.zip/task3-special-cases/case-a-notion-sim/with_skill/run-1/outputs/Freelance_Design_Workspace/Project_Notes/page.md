[Notion Page: Project Notes]
(currently empty scratch notes, unorganized)
Client: Aria Studio. Logo redesign, deadline mid-October. Rate: 1200 USD flat.
