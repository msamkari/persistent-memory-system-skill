# Skill Benchmark: persistent-memory-system

**Model**: <model-name>
**Date**: 2026-09-16T19:13:04Z
**Evals**: 1, 2, 3, 4, 5 (3 runs each per configuration)

## Summary

| Metric | With Skill | Without Skill | Delta |
|--------|------------|---------------|-------|
| Pass Rate | 100% ± 0% | 50% ± 33% | +0.50 |
| Time | 145.7s ± 83.9s | 125.5s ± 69.6s | +20.2s |
| Tokens | 80826 ± 7046 | 69922 ± 5589 | +10904 |