Freelance Writing - Decision and History Log (Deep Storage)

This file holds the full, uncompressed history of decisions, lessons, and notable events for the Freelance Writing project. Nothing here gets deleted - only compressed into short summary lines once entries pile up past a reasonable point, and even then the full uncompressed version is saved into System_Previous_MDs first, before any compression happens. Right now this file is short, so nothing has been compressed yet.

2026-09-16 - Migration. This entire persistent memory system was built by migrating the project's original single notes.md file (which had about a year of unsorted notes and decisions in it, no dates on most entries, one Markdown table) into this structured system. The original notes.md was left in place, unmodified, at Freelance_Writing/notes.md as an extra safety copy. Every distinct piece of information in it was carried into either this log or 01_Project_Summary.md. Assumptions made during this migration (content language English, file naming English, using the one available connected storage location) were flagged to the project owner and are recorded in 03_Language_And_Formatting_Rules.md.

2026-03-12 - Decision: raised the base rate for new clients from 0.12 per word to 0.15 per word. Reasoning recorded in the original note: Nadia Corp agreed to the new rate without pushback, which was taken as a signal the higher rate was sustainable going forward.

Undated (exact date not given in the original notes) - Lesson learned: Nadia Corp requires all articles in British English. This was forgotten once, which required redoing two already-delivered pieces. Noted as a recurring point to double check.

Undated - Bright Media invoice terms are net-30, and they have been late on payment twice. No specific dates were recorded for those late payments in the original note.

Undated (work paused starting 2026-06) - Bright Media paused ongoing work due to a budget freeze on their end. As of the last update to these notes, work had not resumed and no follow-up had been logged yet.

Undated - The style guide link Nadia Corp had originally shared was lost, and had not been re-requested as of the last update to these notes.

Undated - Workflow change: switched from sending drafts as email attachments to sharing them through a shared Google Doc, which reduced version-confusion problems compared to email attachments.

Undated - Standing reminder: quarterly estimated tax payments are due mid-month.
