Freelance Writing - Archive Rule

This file defines how the persistent memory system for the Freelance Writing project is kept up to date without ever deleting old information.

No file inside System_Current_MD is ever deleted directly. When any file in this folder needs a real update, the following steps happen in the same session as the update:

1. The current version of that file is moved into System_Previous_MDs, inside a subfolder named for the current month in YYYY-MM format (for example 2026-09). That subfolder is created automatically if it does not exist yet.

2. The moved file gets today's date appended to its name in YYYY-MM-DD format. If more than one update to the same file happens on the same day, a letter is appended as well (b, c, and so on) to avoid overwriting the earlier one from that same day.

3. A new file is created with the original name (no date) inside System_Current_MD, containing the updated content.

4. Before considering the update done, the contents of both folders are actually re-listed to confirm the three steps above really happened, rather than assuming they worked.

Freshness check: at the start of any session where a file in this folder might be updated, a snapshot of the current file list and modification times is taken first. Right before actually writing over any specific file, that file's real current state is checked again and compared to the snapshot. If it changed in between (meaning another session edited it), the write stops, the conflict is reported openly, the current version is re-read in full, and the two versions are merged instead of one overwriting the other.

Origin note: this archive rule file was created on 2026-09-16, as part of migrating this project from a single unorganized notes.md file into this structured system. Nothing from the original notes.md was deleted - it remains saved at Freelance_Writing/notes.md exactly as it was, and every piece of its content was also carried into the files in this folder (mainly 01_Project_Summary.md and 02_Decision_And_History_Log.md).
