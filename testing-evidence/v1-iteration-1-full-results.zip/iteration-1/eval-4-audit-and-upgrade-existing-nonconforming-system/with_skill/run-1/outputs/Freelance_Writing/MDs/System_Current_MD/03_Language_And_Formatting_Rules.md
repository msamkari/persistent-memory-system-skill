Freelance Writing - Language and Formatting Rules

Content language: English. This was carried over from the original notes.md, which was entirely in English, and matches the fact that client-facing work (Nadia Corp, Bright Media) is conducted in English. This is a starting assumption made during migration on 2026-09-16 rather than something the project owner explicitly confirmed - it can be switched at any time, including mixing languages freely if that becomes more natural.

File and folder naming: English, using underscores instead of spaces. This is the default naming convention and was also assumed rather than explicitly chosen during this migration.

General formatting rules that apply to every file in this system:

No tables. The client list that used to be a Markdown table in notes.md is written below as plain lines instead.

No heavy Markdown structure - no multiple heading levels with #, no long chains of horizontal rule dashes, no deeply nested lists. Plain paragraphs with simple text titles and blank lines between sections, so the files stay readable even in a viewer that does not render Markdown.

Dates are always written as YYYY-MM-DD. Where the original notes.md gave a date, it was preserved. Where no exact date was given (several notes only said "recently" or gave no date at all), this is marked explicitly as undated rather than inventing a date.
