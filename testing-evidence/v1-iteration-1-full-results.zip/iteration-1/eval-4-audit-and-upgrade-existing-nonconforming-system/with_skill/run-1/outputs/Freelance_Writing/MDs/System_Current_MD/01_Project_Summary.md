Freelance Writing - Project Summary (Hot Cache)

Last rebuilt: 2026-09-16, during migration from the old single notes.md file into this structured system. This file is meant to be the fast, current snapshot - see 02_Decision_And_History_Log.md for the full story behind each item.

Active clients and rates:

Nadia Corp - 0.15 per word - status active. Requires all articles in British English. This was missed once in the past and cost a redo of two pieces, so it is worth double-checking before delivery.

Bright Media - 0.20 per word - status paused since 2026-06, due to a budget freeze on their side. Invoice terms with them are net-30, and they have been late on payment twice in the past.

Current base rate for new clients: 0.15 per word. This was raised from 0.12 per word on 2026-03-12 (see decision log for the reasoning).

Open items / things to follow up on:

Follow up with Bright Media about resuming work - paused since 2026-06, no resolution recorded yet.

Re-request the style guide link from Nadia Corp - the original link was lost and was never re-obtained as of the last note.

Recurring reminder: quarterly estimated tax payments are due mid-month - worth a calendar check each quarter.

Current workflow note: drafts are shared with clients via a shared Google Doc rather than email attachments, which has reduced version-confusion problems.
