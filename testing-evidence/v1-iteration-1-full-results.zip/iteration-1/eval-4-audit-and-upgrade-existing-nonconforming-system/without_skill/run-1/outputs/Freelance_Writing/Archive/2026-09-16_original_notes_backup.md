# نسخة أرشيفية كاملة من notes.md الأصلي (قبل إعادة التنظيم)

> تاريخ الأرشفة: 2026-09-16
> هذا نسخة طبق الأصل عن الملف الأصلي "notes.md" كما كان قبل إعادة الهيكلة، محفوظة هنا للتأكد من عدم فقدان أي معلومة قديمة أثناء الترقية لنظام الذاكرة المنظم. الملف الأصلي نفسه بقي في مكانه بدون حذف أو تعديل.

---

Freelance Writing - Notes

Client list:
| Client | Rate | Status |
|--------|------|--------|
| Nadia Corp | 0.15/word | active |
| Bright Media | 0.20/word | paused |

Random notes (2025-10 to 2026-09, unsorted):

- Nadia Corp wants all articles in British English, forgot this once and
  had to redo two pieces.
- Invoice terms with Bright Media are net-30, they were late twice.
- IMPORTANT DECISION (2026-03-12): raised base rate from 0.12 to 0.15/word
  for all new clients after Nadia Corp agreed without pushback.
- Need to follow up with Bright Media about resuming work, paused since
  2026-06 due to their budget freeze.
- Style guide link for Nadia Corp: (lost the link, ask them again)
- Another note: started using a shared Google Doc for drafts instead of
  email attachments, much less version confusion.
- Tax note: remember quarterly estimated payments due mid-month.
