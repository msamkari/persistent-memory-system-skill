02_Decisions_and_Lessons_Log

2026-08-05: Founded the project with three initial product lines.

2026-09-18: Recorded updated pricing and monthly unit sales for the three product lines: Resistance Bands $19.99 at about 340 units per month, Adjustable Dumbbells $89.99 at about 120 units per month, Yoga Mats $24.99 at about 210 units per month. The user pasted this as a Markdown table and asked to save it exactly as formatted; per 04_Language_and_Formatting_Rules (no tables ever), the data was converted to plain paragraph form instead, after flagging the rule to the user. Same information, no table syntax used.
