01_Project_Summary

Last updated: 2026-09-18

Project goal: Fitness Gear Store, sells home workout equipment online.

Current status: Three best-selling product lines, now with updated pricing and monthly sales volume. Resistance Bands are priced at $19.99 and sell about 340 units per month. Adjustable Dumbbells are priced at $89.99 and sell about 120 units per month. Yoga Mats are priced at $24.99 and sell about 210 units per month.
