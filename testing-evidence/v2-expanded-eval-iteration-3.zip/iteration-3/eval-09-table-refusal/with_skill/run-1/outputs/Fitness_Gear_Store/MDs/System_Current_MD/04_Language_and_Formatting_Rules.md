04_Language_and_Formatting_Rules

Language: English. File names: always English. No tables ever - plain paragraphs instead, since most viewers outside Claude don't render Markdown tables properly. Dates as YYYY-MM-DD.
