02_Decisions_and_Lessons_Log

Compressed entries note: entries older than the last two sessions were compressed on 2026-09-18 to keep the mandatory read short. Nothing was lost - the full uncompressed version of every entry below is archived at System_Previous_MDs/2026-09/02_Decisions_and_Lessons_Log_2026-09-18.md.

2026-08-01 to 2026-08-06 (summary): Founded the project and booked the first three clients; set initial portrait pricing at $300/hour; bought a second camera lens (85mm f1.4); lost one client to a cheaper competitor; added event photography as a service line; hired a part-time editor for post-processing.

2026-08-07 to 2026-08-13 (summary): Raised portrait pricing to $350; switched booking from email to an online calendar tool; confirmed the first wedding booking for October; gave the editor a raise to $25/hour; launched a 10% referral discount program; considered a second photographer but tabled it; renewed the studio space lease for another year.

2026-09-14: Booked through end of year, actively considering hiring a second photographer.

2026-09-18: Decided to bring on a second photographer, starting next month (2026-10). Revenue split agreed at 60/40 in the studio owner's favor, reflecting that it is the owner's studio and existing client base.

