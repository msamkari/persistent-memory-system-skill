01_Project_Summary

Last updated: 2026-09-14

Project goal: Photography Studio, portrait and event photography business.

Current status: Booked through end of year, considering hiring a second photographer.
