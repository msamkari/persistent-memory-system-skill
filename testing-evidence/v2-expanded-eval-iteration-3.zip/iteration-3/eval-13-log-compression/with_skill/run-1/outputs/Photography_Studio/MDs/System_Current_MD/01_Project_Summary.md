01_Project_Summary

Last updated: 2026-09-18

Project goal: Photography Studio, portrait and event photography business.

Current status: Booked through end of year. Bringing on a second photographer starting 2026-10, with revenue split 60/40 in the studio owner's favor (owner's studio and client base). See 02_Decisions_and_Lessons_Log for the full decision entry.
