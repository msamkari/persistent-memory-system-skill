00_Archiving_Rule

No direct deletion of system files ever. Archive superseded versions to System_Previous_MDs/[YYYY-MM]/ with today's date, create a fresh current file, verify. Narrative-historical files (like 02) get periodic compression once they exceed roughly 10-12 entries or grow long enough to noticeably slow the mandatory read - compress older entries into one or two summary lines per batch, keep the last session or two in full detail, and archive the full uncompressed version first before compressing (compression never loses information, it just reduces repeated read size).
