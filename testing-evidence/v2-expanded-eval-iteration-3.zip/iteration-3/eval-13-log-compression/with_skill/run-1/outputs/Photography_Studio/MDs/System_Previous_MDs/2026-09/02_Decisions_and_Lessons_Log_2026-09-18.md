02_Decisions_and_Lessons_Log

2026-08-01: Founded the project, booked first three clients.

2026-08-02: Decided on pricing: $300 for a one-hour portrait session.

2026-08-03: Purchased a second camera lens (85mm f1.4).

2026-08-04: Lost a client to a cheaper competitor, noted for future pricing discussion.

2026-08-05: Added event photography as a service line.

2026-08-06: Hired a part-time editor for post-processing.

2026-08-07: Raised portrait pricing to $350 after positive demand signal.

2026-08-08: Switched booking system from email to an online calendar tool.

2026-08-09: First event booking (wedding) confirmed for October.

2026-08-10: Editor requested a raise, agreed to $25/hour up from $20/hour.

2026-08-11: Added a referral discount program, 10% off for referred clients.

2026-08-12: Considered hiring a second photographer, tabled for now.

2026-08-13: Renewed studio space lease for another year.

2026-09-14: Booked through end of year, actively considering hiring a second photographer.

2026-09-18: Decided to bring on a second photographer, starting next month (2026-10). Revenue split agreed at 60/40 in the studio owner's favor, reflecting that it is the owner's studio and existing client base.

