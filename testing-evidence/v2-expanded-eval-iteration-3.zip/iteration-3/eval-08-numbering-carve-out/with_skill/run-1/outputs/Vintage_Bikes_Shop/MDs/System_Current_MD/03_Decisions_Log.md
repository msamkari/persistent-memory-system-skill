03_Decisions_Log

2026-08-20: Founded the project and this numbering scheme (01=rules, 02=summary, 03=log), deliberately different from other projects.

2026-09-18: Decided to add online sales through a new Shopify store, to launch next month (planned around October 2026), running alongside the existing physical shop.
