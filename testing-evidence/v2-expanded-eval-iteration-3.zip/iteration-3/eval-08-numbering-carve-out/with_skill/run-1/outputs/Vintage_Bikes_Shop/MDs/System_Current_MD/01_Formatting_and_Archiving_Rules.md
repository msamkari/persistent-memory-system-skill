01_Formatting_and_Archiving_Rules

Note on numbering (documented intentionally, do not renumber): this project started before the standard 00-04 scheme was adopted elsewhere. Here, 01 = rules file (this one), 02 = project summary, 03 = decisions log. This numbering is final for this project and must not be changed to match any other project's scheme.

No direct deletion of system files ever. Archive superseded versions to System_Previous_MDs/[YYYY-MM]/ with today's date, then create a fresh current file.
