02_Project_Summary

Last updated: 2026-08-20

Project goal: Vintage Bikes Shop, restores and resells vintage bicycles.

Current status: One storefront, restoring about 4 bikes per month.
