02_Project_Summary

Last updated: 2026-09-18

Project goal: Vintage Bikes Shop, restores and resells vintage bicycles.

Current status: One physical storefront, restoring about 4 bikes per month. Expanding into online sales through a new Shopify store, planned to launch next month (around October 2026), running alongside the physical shop.
