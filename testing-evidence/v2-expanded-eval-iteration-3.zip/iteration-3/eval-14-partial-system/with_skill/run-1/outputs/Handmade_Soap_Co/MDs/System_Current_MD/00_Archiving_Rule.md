00_Archiving_Rule

No direct deletion of system files ever. Archive superseded versions with today's date, create a fresh current file, verify.
