04_Language_and_Formatting_Rules

Content language: English, matching how you write to me. If you want a different language for the content of these files going forward, just say so and this file gets updated to reflect that.

File and folder naming: English, using the numbered scheme (00, 01, 02, and so on). This matches the naming already used in 00_Archiving_Rule.md, so it continues what was already started rather than changing it.

Formatting rules that apply to every file in this system:

No tables.

No heavy Markdown — no multiple heading levels, no repeated dividers, no nested lists. Plain paragraph headers only (a plain line of text, not a Markdown heading), so the content still reads fine even in a plain text viewer that does not render Markdown.

Clear paragraphs with a blank line between sections.

Dates and numbers written as YYYY-MM-DD.

Last updated: 2026-09-18.
