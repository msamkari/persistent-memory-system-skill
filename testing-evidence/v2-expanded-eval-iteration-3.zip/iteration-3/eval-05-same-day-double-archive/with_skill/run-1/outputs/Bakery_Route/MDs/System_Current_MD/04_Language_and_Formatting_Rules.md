04_Language_and_Formatting_Rules

Language: English, matching the user's messages. File names: always English. No tables. Dates as YYYY-MM-DD.
