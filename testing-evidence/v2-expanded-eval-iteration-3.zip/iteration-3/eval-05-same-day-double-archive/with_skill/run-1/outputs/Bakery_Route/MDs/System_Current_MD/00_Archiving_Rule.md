00_Archiving_Rule

No system file is ever deleted directly. Every update moves the current file to System_Previous_MDs/[YYYY-MM]/ with today's date appended to the filename (and a letter suffix b, c... if more than one update happens the same day), then creates a fresh file with the original name. Verify with a fresh folder listing after every archive operation.
