01_Project_Summary

Last updated: 2026-09-16

Project goal: Bakery Route, a delivery route service that brings fresh bread from three partner bakeries to subscribers twice a week.

Current status: 50 active subscribers. Delivery days are Tuesday and Friday.
