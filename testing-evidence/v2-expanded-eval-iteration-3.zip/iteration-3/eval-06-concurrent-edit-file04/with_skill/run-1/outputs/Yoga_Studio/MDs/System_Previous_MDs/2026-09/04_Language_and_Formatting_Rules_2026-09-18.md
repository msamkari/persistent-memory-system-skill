04_Language_and_Formatting_Rules

Language: English by default. File names: always English. No tables. Dates as YYYY-MM-DD.

New rule not yet logged in the narrative log: as of 2026-09-16, class schedule changes must always be confirmed by both instructors in writing before being reflected in the project summary.
