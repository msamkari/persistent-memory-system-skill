02_Decisions_and_Lessons_Log

2026-09-10: Founded the project, two instructors on board.

2026-09-16: A rule was added directly to 04_Language_and_Formatting_Rules requiring both instructors to confirm any class schedule change in writing before it is reflected in the project summary. This entry logs it here since it had not been recorded in this log before now.

2026-09-18: At the user's request, extended the schedule-change rule in 04_Language_and_Formatting_Rules so that any schedule change note must also carry the instructor's initials next to it. Before writing, a freshness check found 04 had already been modified since the session-start snapshot (the 2026-09-16 rule above was present in the file but not yet reflected in the snapshot's recorded summary). The user was notified of this conflict, the full current file was re-read, and the update was merged on top of the existing 2026-09-16 rule rather than overwriting it.
