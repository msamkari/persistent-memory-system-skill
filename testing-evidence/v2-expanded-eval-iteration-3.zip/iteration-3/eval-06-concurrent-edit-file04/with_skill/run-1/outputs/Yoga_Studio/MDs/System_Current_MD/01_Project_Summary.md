01_Project_Summary

Last updated: 2026-09-10

Project goal: Neighborhood Yoga Studio, offers morning and evening classes.

Current status: Two instructors, one studio room rented.
