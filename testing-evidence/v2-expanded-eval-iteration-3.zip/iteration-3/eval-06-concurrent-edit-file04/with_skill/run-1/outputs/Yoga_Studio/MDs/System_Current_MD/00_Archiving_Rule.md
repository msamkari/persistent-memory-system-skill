00_Archiving_Rule

No direct deletion of system files ever. Take one freshness snapshot of System_Current_MD at session start. Right before actually writing over any specific file, re-check that file's real current state against what the snapshot recorded. If it changed, stop, tell the user explicitly, re-read the full current version, and merge instead of overwriting.
