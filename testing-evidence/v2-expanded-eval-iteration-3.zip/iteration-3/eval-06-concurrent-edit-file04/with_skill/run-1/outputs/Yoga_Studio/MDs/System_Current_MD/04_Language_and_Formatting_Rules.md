04_Language_and_Formatting_Rules

Last updated: 2026-09-18

Language: English by default. File names: always English. No tables. Dates as YYYY-MM-DD.

Schedule change rule, added 2026-09-16: class schedule changes must always be confirmed by both instructors in writing before being reflected in the project summary.

Schedule change rule, added 2026-09-18: any schedule change note must also include the instructor's initials next to it.
