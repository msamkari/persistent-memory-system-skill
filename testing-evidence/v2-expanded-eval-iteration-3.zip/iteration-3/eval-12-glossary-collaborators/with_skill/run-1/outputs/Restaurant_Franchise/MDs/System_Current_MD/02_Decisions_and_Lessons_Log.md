02_Decisions_and_Lessons_Log

2026-09-01: Signed the lease for Location 2 with partner Sara.
