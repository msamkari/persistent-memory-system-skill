01_Project_Summary

Last updated: 2026-09-01

Project goal: Restaurant Franchise expansion, opening a second location run jointly with a business partner, Sara.

Current status: Location 1 profitable. Location 2 lease signed, opening planned for November.
