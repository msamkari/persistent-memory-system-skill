Glossary

Loc2 — shorthand for the second restaurant location
FOH — Front of House staff
BOH — Back of House staff
