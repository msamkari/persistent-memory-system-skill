Language and Formatting Rules — Slow Mornings (current state)

Content language

English. The owner's founding message was written entirely in English with no other language mixed in, so English was used as the working assumption for this file's content rather than asked as a separate question in this exchange. If the owner writes to Claude in a different language later, the practical default is for replies (and any new writing) to match whichever language he is using at that moment, rather than sticking to one fixed language regardless of how he writes — unless he states a fixed preference explicitly. This assumption is flagged to him directly and can be corrected any time.

File and folder naming

English, with underscores instead of spaces (for example: Slow_Mornings, Content_Calendar). This is this system's default when no other preference is stated, and — like the content-language choice — it was assumed rather than separately confirmed with the owner in this founding exchange. If he would rather have file names in Arabic or some other convention, this is changed on request; nothing about the existing structure would need to be rebuilt from scratch to do that.

General formatting used across every file in this system

No tables. No heavy Markdown (no stacks of multi-level headings, no repeated horizontal rule lines, no deeply nested lists) — most document viewers outside Claude do not render Markdown formatting, so every file needs to read cleanly as plain text on its own. Instead: clear paragraphs, plain-text section titles (an ordinary line of text, not a Markdown heading), and a blank line between sections. Dates and numbers are written in a single consistent format, YYYY-MM-DD, everywhere in this system.
