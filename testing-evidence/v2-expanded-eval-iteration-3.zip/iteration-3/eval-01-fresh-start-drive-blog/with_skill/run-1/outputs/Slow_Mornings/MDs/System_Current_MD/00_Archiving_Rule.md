Archiving Rule — Slow Mornings Persistent Memory System

Purpose of this file

This file defines how the memory system for the Slow Mornings blog is kept up to date without ever losing older information. Every future session on this project follows this rule automatically, without needing to be reminded.

Core rule: no system file is ever deleted directly

None of the files in this system are ever deleted outright. When something changes, the old version is preserved in an archive folder rather than overwritten and discarded.

How an update to a current-state file works

The current-state files are: 00_Archiving_Rule, 01_Project_Summary, 04_Language_and_Formatting_Rules, 05_Content_Calendar, and any later standing-rule file added at the next free number (06, 07, and so on). Whenever one of these is actually updated, the following happens in the same session, before anything else is treated as done:

First, immediately before writing, the current real state of that specific file is checked again (by re-reading it) to make sure no other session changed it in the meantime. If it has changed unexpectedly, that conflict is reported to the owner right away instead of being silently overwritten, and the two versions are merged by hand.

Second, the existing file is moved into System_Previous_MDs/[current month as YYYY-MM]/ (this subfolder is created automatically if it does not already exist), and the date of the move is appended to the moved file's name as filename_YYYY-MM-DD. If more than one update happens to the same file on the same day, a letter is appended as well (b, c, and so on) to keep them distinct.

Third, a new file is created with the original name (no date in the name) inside System_Current_MD, containing the updated content.

Fourth, the result is actually verified by listing the contents of both folders again — never assumed to have worked just because no error was shown.

How the narrative-historical files are handled

02_Decisions_and_Lessons_Log and 03_Content_Ideas_and_Notes_Log are append-only. Nothing is ever removed from them directly. If one of them grows past roughly 10 to 12 entries, or becomes long enough to noticeably slow down the mandatory full read described below, the older entries that are not tied to a currently active decision get compressed into a one- or two-line summary per batch, while the most recent session or two stay in full detail at the top of the file. Before any such compression happens, the full uncompressed version of the file is saved into that month's System_Previous_MDs archive folder first — compression never loses information, it only shortens what gets read at the start of every session.

Mandatory read at the start of every session

At the start of every future session connected to this project, every file inside MDs/System_Current_MD/ is read in full before responding to anything else — even if the message looks like an ordinary question with no obvious connection to the blog, and even if there is no explicit reminder to check memory. If the storage location cannot be reached for any reason (connection error, lost permission, disconnected account), that is stated plainly to the owner before anything else — the session never proceeds as though the read happened and guesses instead.

Immediate save

Any file created and shown to the owner during a session is saved into this storage location in that same reply, and becomes an official part of the system right away, without waiting for a separate confirmation.

Automatic logging of new decisions

Any new decision or meaningful development that comes up during a session is written into the appropriate narrative file (and into any current-state file it affects, such as the project summary) during that same session, without waiting to be asked.
