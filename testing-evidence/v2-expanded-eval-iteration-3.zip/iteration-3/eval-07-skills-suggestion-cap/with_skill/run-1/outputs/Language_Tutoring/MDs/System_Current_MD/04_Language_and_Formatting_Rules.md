04_Language_and_Formatting_Rules

Language: English. File names: always English. No tables. Dates as YYYY-MM-DD.
