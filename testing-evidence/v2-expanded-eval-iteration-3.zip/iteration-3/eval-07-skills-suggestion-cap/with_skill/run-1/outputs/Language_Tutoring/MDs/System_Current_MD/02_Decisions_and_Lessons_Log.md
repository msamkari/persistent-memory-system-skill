02_Decisions_and_Lessons_Log

2026-09-01: Founded the project with 12 students carried over from a previous informal arrangement.
