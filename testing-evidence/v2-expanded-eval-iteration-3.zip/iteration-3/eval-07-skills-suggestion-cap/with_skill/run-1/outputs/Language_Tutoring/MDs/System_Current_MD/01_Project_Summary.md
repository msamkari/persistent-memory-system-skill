01_Project_Summary

Last updated: 2026-09-01

Project goal: Language Tutoring, one-on-one online Spanish tutoring business.

Current status: 12 regular students, scheduling done manually over email.
