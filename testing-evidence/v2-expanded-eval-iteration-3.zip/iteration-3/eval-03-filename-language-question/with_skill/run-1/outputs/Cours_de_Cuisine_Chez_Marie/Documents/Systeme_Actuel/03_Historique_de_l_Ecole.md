Historique de l'ecole - Cours de Cuisine Chez Marie

Ce fichier garde une trace narrative de tout ce qui concerne concretement le fonctionnement de l'ecole au fil du temps : cours donnes, changements de contenu pedagogique, retours d'eleves, evenements particuliers, etc. Il complete le journal des decisions (02), qui se concentre plutot sur les choix strategiques (prix, planning, orientation generale).

2026-09-18 - Ouverture du dossier. Aucun historique de cours ou d'eleves n'a encore ete partage par Marie. Ce fichier sera rempli au fur et a mesure des sessions suivantes.
