Regle d'archivage du systeme de memoire

Objectif : ne jamais perdre une information ancienne, meme quand un fichier est mis a jour.

Principe general : aucun fichier de ce systeme n'est jamais supprime directement. Quand un fichier de la categorie "etat actuel" doit etre remplace (par exemple apres une nouvelle decision sur les prix ou le planning), la version qui va etre remplacee est d'abord deplacee dans les archives, puis seulement apres une nouvelle version est creee a sa place.

Etapes suivies a chaque mise a jour d'un fichier d'etat actuel (dossier Systeme_Actuel) :

1. Le fichier existant est deplace vers Documents/Systeme_Precedent/AAAA-MM/ (le sous-dossier du mois en cours est cree automatiquement s'il n'existe pas).
2. La date du jour est ajoutee au nom du fichier deplace, au format nom_du_fichier_AAAA-MM-JJ. Si plusieurs mises a jour ont lieu le meme jour, une lettre est ajoutee (b, c, etc.).
3. Un nouveau fichier est cree avec le nom original (sans date) dans Systeme_Actuel, avec le contenu a jour.
4. La reussite de ces trois etapes est verifiee reellement (en relisant le contenu des deux dossiers), pas seulement supposee.

Verification de fraicheur avant ecriture : au debut de chaque session ou une mise a jour est probable, un instantane (liste des fichiers et dates de modification) du dossier Systeme_Actuel est pris. Juste avant d'ecrire reellement sur un fichier donne, son etat reel est revérifie et compare a cet instantane. Si le fichier a change entre-temps (une autre session l'a modifie), la mise a jour s'arrete, le conflit est signale explicitement a Marie, et les deux versions sont fusionnees plutot que l'une ecrasant l'autre.

Cette regle s'applique automatiquement, sans attendre une demande explicite, a chaque fois qu'un fichier d'etat actuel est modifie, qu'un nouveau document est presente a Marie, ou qu'un fichier narratif-historique depasse une taille raisonnable et doit etre compresse (voir 02).

Date de creation de cette regle : 2026-09-18.
