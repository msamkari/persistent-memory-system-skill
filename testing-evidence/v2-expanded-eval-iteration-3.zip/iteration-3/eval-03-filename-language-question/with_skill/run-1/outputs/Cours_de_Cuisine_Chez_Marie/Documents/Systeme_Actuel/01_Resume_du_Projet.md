Resume du projet - Cours de Cuisine Chez Marie

Nature du projet : petite ecole de cuisine situee a Montreal, geree par Marie. Le systeme de memoire ci-present sert a garder trace des decisions et details du projet d'une conversation a l'autre, en particulier les decisions sur les prix des cours et le planning des sessions.

Etat au 2026-09-18 (creation du systeme) : le systeme de memoire vient d'etre mis en place a la demande de Marie. Aucune decision de prix ou de planning n'a encore ete communiquee a ce stade - ce fichier sera mis a jour des que des elements concrets (tarifs, horaires, types de cours, nombre de places, etc.) seront connus.

Elements encore a preciser avec Marie lors des prochaines sessions :
- Liste des cours offerts et leur contenu.
- Grille tarifaire actuelle (par cours, par forfait, par abonnement, etc.).
- Planning recurrent (jours, heures, frequence).
- Nombre maximal de participants par cours.
- Lieu exact et logistique (materiel fourni, ingredients, etc.).

Ce fichier represente l'etat courant du projet. Il est entierement remplace a chaque mise a jour importante (l'ancienne version est archivee, jamais supprimee - voir 00_Regle_Archivage).
