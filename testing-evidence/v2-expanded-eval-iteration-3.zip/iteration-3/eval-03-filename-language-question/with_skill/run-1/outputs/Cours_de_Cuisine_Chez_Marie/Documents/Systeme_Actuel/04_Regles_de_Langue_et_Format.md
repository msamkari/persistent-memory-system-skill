Regles de langue et de format - Cours de Cuisine Chez Marie

Langue du contenu : francais. Marie a indique explicitement preferer que tout le systeme soit en francais. Regle appliquee : chaque reponse suit la langue du message de Marie au moment donne, mais par defaut (et sauf message dans une autre langue) le contenu est redige en francais.

Langue des noms de fichiers et de dossiers : francais, y compris pour la structure elle-meme (par exemple "Documents" plutot que "MDs", "Systeme_Actuel" plutot que "System_Current_MD", "Systeme_Precedent" plutot que "System_Previous_MDs"). Ceci est une decision explicite de Marie, prise des le premier message du 2026-09-18, ou elle a precise vouloir le francais "y compris les noms de fichiers si possible, pas seulement le contenu". Les numeros de prefixe (00, 01, 02, 03, 04...) restent tels quels : ce sont des reperes techniques du systeme, pas du contenu linguistique.

Format des fichiers de ce systeme :
- Pas de tableaux.
- Pas de mise en forme Markdown lourde (pas de titres a plusieurs niveaux avec # ou ##, pas de lignes de separation ---, pas de listes imbriquees complexes) : le texte doit rester lisible meme affiche comme texte brut, sans mise en forme.
- Des paragraphes clairs avec des titres simples (une ligne de titre normale, pas un titre Markdown) et des lignes vides entre les sections.
- Les dates et les nombres au format AAAA-MM-JJ pour les dates.

Ce fichier represente l'etat courant des regles. Il est remplace entierement a chaque mise a jour (l'ancienne version est archivee, jamais supprimee - voir 00_Regle_Archivage).
