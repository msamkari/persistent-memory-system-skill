04_Language_and_Formatting_Rules

Langue: le contenu suit la langue du message de l'utilisateur au moment de la reponse. Noms de fichiers: toujours en anglais (decision prise a la creation du systeme). Pas de tableaux. Dates au format AAAA-MM-JJ.
