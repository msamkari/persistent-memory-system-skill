00_Archiving_Rule

Regle fixe: jamais de suppression directe d'un fichier systeme. Toute mise a jour deplace l'ancien fichier vers System_Previous_MDs/[AAAA-MM]/ avec la date du jour ajoutee au nom, puis un nouveau fichier est cree avec le nom original. Verification effective apres chaque operation via une nouvelle liste du dossier.
