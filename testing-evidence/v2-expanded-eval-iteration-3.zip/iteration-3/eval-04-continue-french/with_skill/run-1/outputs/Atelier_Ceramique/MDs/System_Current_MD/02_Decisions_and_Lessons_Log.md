02_Decisions_and_Lessons_Log

2026-07-15: Choix du fournisseur ArgilePro apres comparaison de trois fournisseurs d'argile locaux, pour un meilleur rapport qualite-prix.
