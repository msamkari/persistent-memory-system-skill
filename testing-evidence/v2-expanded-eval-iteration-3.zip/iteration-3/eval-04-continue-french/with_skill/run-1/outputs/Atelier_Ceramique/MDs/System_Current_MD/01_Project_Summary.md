01_Project_Summary

Derniere mise a jour: 2026-08-01

Objectif du projet: Atelier Ceramique, un petit atelier de poterie artisanale a Lyon. Vend des pieces uniques sur commande.

Etat actuel: Deux fours en activite, un troisieme est en projet d'achat. Le principal fournisseur d'argile est ArgilePro, choisi le 2026-07-15 pour son prix stable.

Decisions cles: Fournisseur d'argile ArgilePro retenu apres comparaison de trois options.
