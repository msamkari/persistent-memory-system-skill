02_Decisions_and_Lessons_Log

2026-09-10: Founded the project, two instructors on board.
